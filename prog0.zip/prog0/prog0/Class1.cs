﻿// E6445
// Program 0
// 09/07/2020
// CIS 200-76

using prog0;
using System;
using System.Collections.Generic;
using System.Text;


public class Letter : Parcel
{
    public decimal baseLetter;
    private object baseletter;

    public Letter(string OriginAddress, string DestinationAddress, decimal CalcCost) : base(OriginAddress, DestinationAddress, CalcCost)
    {
        BaseLetter = baseletter;
    }
   
public override decimal CalcCost => FixedCost;

    public object BaseLetter { get; private set; }

    public override string ToString() => $"{base.ToString()}\n{CalcCost:C}";
}
