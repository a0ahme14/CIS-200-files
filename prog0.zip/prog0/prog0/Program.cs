﻿// E6445
// Program 0
// 09/07/2020
// CIS 200-76

using System;
namespace prog0
{
    public class Address
    {
        public string name;
        public string addressline1;
        public string addressline2;
        public string city;
        public string state;
        public int zipcode;

        public Address(string Name, string Address1, string Address2, string City, string State, int Zip)
        {
            //implicit call to object constructor 
            name = Name;
            addressline1 = Address1;
            addressline2 = Address2;
            city = City;
            state = State;
            zipcode = Zip;
        }

        //property that gets and sets customer's name
        public string Name
        {
            get
            {
                return Name;
            }
            set
            {
                if (string.IsNullOrEmpty(name)) //validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Name)} invalid input");
                }
                name = value;
            }


        }
        //property that gets and sets address line 1
        public string Address1
        {
            get
            {
                return Address1;
            }
            set
            {
                if (string.IsNullOrEmpty(Address1)) //validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Address1)} invalid input");
                }
                Address1 = value;
            }


        }
        //property that gets and sets city name
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                if (string.IsNullOrEmpty(city)) //validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(city)} invalid input");
                }
                city = value;
            }


        }

        //property that gets and sets the state
        public string State
        {
            get
            {
                return State;
            }
            set
            {
                if (string.IsNullOrEmpty(state)) //validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(State)} invalid input");
                }
                State = value;
            }


        }
    }
    public class Parcel
    {
        public string originaddress;
        public string destinationaddress;
        private decimal calccost;
        private decimal fixedcost;
        private object calcCost;

        public Parcel(string originAddress, string destinationAddress, object calCost)
        {
            originaddress = originAddress;
            destinationaddress = destinationAddress;
            this.calcCost = calcCost;
        }

        public Parcel(string OriginAddress, string DestinationAddress, decimal CalcCost, decimal FixedCost)
            
        {
            originaddress = OriginAddress;
            destinationaddress = DestinationAddress;
            calccost = CalcCost;
            fixedcost = FixedCost;
        }


        //property that gets and sets origin address
        public string OriginAddress
        {
            get
            {
                return OriginAddress;
            }
            set
            {
                if (string.IsNullOrEmpty(OriginAddress)) //validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(OriginAddress)} invalid input");
                }
                OriginAddress = value;
            }
        }
        //property that gets and sets destination address
        public string DestinationAddress
        {
            get
            {
                return DestinationAddress;
            }
            set
            {
                if (string.IsNullOrEmpty(DestinationAddress)) // validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(DestinationAddress)} invalid input");
                }
                DestinationAddress = value;
            }
        }

        public decimal FixedCost
        {
            get
            {
                return FixedCost;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(FixedCost)} must be greater than 0");
                }

                FixedCost = value;
            }
        }
        

        // return cost
        public virtual decimal CalcCost() => FixedCost;

   
    }
    class testLetters
    {
        static void Main(string[] args)

        {

            Parcel Letter = new testLetters ("321 rd", "123 St", 3.5M);

            Console.WriteLine("\nLetter: ");

            Console.WriteLine("  Sender's Address: {0}", Letter.OriginAddress);

            Console.WriteLine("  recipient's Address: {0}", Letter.DestinationAddress);

            Console.WriteLine("  Shipping Cost: {0:C}", Letter.CalcCost());
        }
    }
}