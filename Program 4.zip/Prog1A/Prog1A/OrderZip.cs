﻿// E6445
// Program 4
// 11/23/2020
// CIS 200-76

// File: OrderZip.cs
// compare class that sorts orders by zip

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class OrderZip : IComparer<Parcel>
    {
        // Precondition:  None
        // Postcondition: When d1 < d2, method returns negative #
        //                When d1 == d2, method returns zero
        //                When d1 > d2, method returns positive #
        public int Compare(Parcel d1, Parcel d2)
        {
            if (d1 == null && d2 == null) // Both null?
                return 0;

            if (d2 == null) // Only d2 is null
                return -1;


            int compZip = d2.DestinationAddress.Zip - d1.DestinationAddress.Zip;    // descending order by dest zip
            return compZip;
        }
    }
}
