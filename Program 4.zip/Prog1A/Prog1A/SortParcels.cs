﻿// E6445
// Program 4
// 11/23/2020
// CIS 200-76

// File: SortParcels.cs
// compare class that sorts parcels by type and cost
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class SortParcels : IComparer<Parcel>
    {
        // Precondition:  None
        // Postcondition: When t1 < t2, method returns negative #
        //                When t1 == t1, method returns zero
        //                When t1 > t2, method returns positive #
        public int Compare(Parcel t1, Parcel t2)
        {
            if (t1 == null && t2 == null) // Both null?
                return 0;

            if (t2 == null) // Only t2 is null
                return -1;

            int compType = string.Compare(t1.GetType().ToString(), t2.GetType().ToString());  // type, ascending
            if (compType != 0) // Check for type difference first
                return compType;

            int compCost = decimal.ToInt32(t2.CalcCost() - t1.CalcCost()); // descending order by cost
            return compCost;
        }
    }
}
