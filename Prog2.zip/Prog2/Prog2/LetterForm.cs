﻿// E6445
// Program 2
// 10/19/2020
// CIS 200-76


// File: LetterForm.cs
// This class validates the data in the letter form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {
        
        public LetterForm(List<Address>list)
        {
            InitializeComponent();

            foreach (Address a in list)
            {
                orgtxt.Items.Add(a.Name);
            }
            foreach (Address a in list)
            {
                desttxt.Items.Add(a.Name);
            }

        }

        internal Address OriginAddress // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in orgtxt is returned

            get { return OriginAddress; } // i get error when i put return orgtxt.Text 
            

            // Precondition:  None
            // Postcondition: Text in orgtxt is set to specified value

            //set { orgtxt.Text = value }
        }

        private void orgtxt_Validating(object sender, CancelEventArgs e)
        {
            if (orgtxt == desttxt)
            {
                e.Cancel = true;
                errorProvider1.SetError(orgtxt, "Enter a name");
                Console.WriteLine("Addresses must be different");
                orgtxt.SelectAll();
            }
        }

        internal Address DestinationAddress // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in desttxt is returned
            get { return DestinationAddress; } // // i get error when i put return orgtxt.Text
            
    // Precondition:  None
    // Postcondition: Text in desttxt is set to specified value

    //set { desttxt.Text = value; }
}

        private void desttxt_Validating(object sender, CancelEventArgs e)
        {
            if (orgtxt == desttxt)
            {
                e.Cancel = true;
                errorProvider1.SetError(orgtxt, "Enter a name");
                Console.WriteLine("Addresses must be different");
                desttxt.SelectAll();
            }
        }

        internal decimal FixedCost // Can be accessed by other classes in same namespace
        {
            
            // Precondition:  None
            // Postcondition: Text in desttxt is returned
            get { return FixedCost; }

            // Precondition:  None
            // Postcondition: Text in desttxt is set to specified value
            set {
                decimal cost = 0;
                
                if
                    (cost > 0)
                throw new ArgumentOutOfRangeException("Must be a non-negative integer"); 
                    
                //else
                   // costtxt.Text = totalCost;
                
            }
        }

        // Precondition:  User has initiated click on OkBtn
        // Postcondition: If all controls on form validate, InputBox is dismissed with OK result
        private void okbtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition:  User has initiated click on cancelBtn
        
        private void cancelbtn_Click(object sender, EventArgs e)
        {
            
                this.DialogResult = DialogResult.Cancel;
        }


    }
}
