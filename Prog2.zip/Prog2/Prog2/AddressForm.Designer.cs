﻿namespace Prog2
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.namelbl = new System.Windows.Forms.Label();
            this.addresslbl = new System.Windows.Forms.Label();
            this.citylbl = new System.Windows.Forms.Label();
            this.statelbl = new System.Windows.Forms.Label();
            this.ziplbl = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.addtxt = new System.Windows.Forms.TextBox();
            this.addtxt2 = new System.Windows.Forms.TextBox();
            this.citytxt = new System.Windows.Forms.TextBox();
            this.ziptxt = new System.Windows.Forms.TextBox();
            this.statecob = new System.Windows.Forms.ComboBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.okbtn = new System.Windows.Forms.Button();
            this.cancelbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // namelbl
            // 
            this.namelbl.AutoSize = true;
            this.namelbl.Location = new System.Drawing.Point(39, 9);
            this.namelbl.Name = "namelbl";
            this.namelbl.Size = new System.Drawing.Size(38, 13);
            this.namelbl.TabIndex = 0;
            this.namelbl.Text = "Name:";
            // 
            // addresslbl
            // 
            this.addresslbl.AutoSize = true;
            this.addresslbl.Location = new System.Drawing.Point(29, 43);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(48, 13);
            this.addresslbl.TabIndex = 1;
            this.addresslbl.Text = "Address:";
            // 
            // citylbl
            // 
            this.citylbl.AutoSize = true;
            this.citylbl.Location = new System.Drawing.Point(50, 96);
            this.citylbl.Name = "citylbl";
            this.citylbl.Size = new System.Drawing.Size(27, 13);
            this.citylbl.TabIndex = 2;
            this.citylbl.Text = "City:";
            // 
            // statelbl
            // 
            this.statelbl.AutoSize = true;
            this.statelbl.Location = new System.Drawing.Point(42, 129);
            this.statelbl.Name = "statelbl";
            this.statelbl.Size = new System.Drawing.Size(35, 13);
            this.statelbl.TabIndex = 3;
            this.statelbl.Text = "State:";
            // 
            // ziplbl
            // 
            this.ziplbl.AutoSize = true;
            this.ziplbl.Location = new System.Drawing.Point(52, 160);
            this.ziplbl.Name = "ziplbl";
            this.ziplbl.Size = new System.Drawing.Size(25, 13);
            this.ziplbl.TabIndex = 4;
            this.ziplbl.Text = "Zip:";
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(84, 9);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(100, 20);
            this.nametxt.TabIndex = 5;
            this.nametxt.Validating += new System.ComponentModel.CancelEventHandler(this.nametxt_Validating);
            this.nametxt.Validated += new System.EventHandler(this.nametxt_Validated);
            // 
            // addtxt
            // 
            this.addtxt.Location = new System.Drawing.Point(84, 43);
            this.addtxt.Name = "addtxt";
            this.addtxt.Size = new System.Drawing.Size(100, 20);
            this.addtxt.TabIndex = 6;
            this.addtxt.Validating += new System.ComponentModel.CancelEventHandler(this.addtxt_Validating);
            // 
            // addtxt2
            // 
            this.addtxt2.Location = new System.Drawing.Point(84, 70);
            this.addtxt2.Name = "addtxt2";
            this.addtxt2.Size = new System.Drawing.Size(100, 20);
            this.addtxt2.TabIndex = 7;
            // 
            // citytxt
            // 
            this.citytxt.Location = new System.Drawing.Point(84, 96);
            this.citytxt.Name = "citytxt";
            this.citytxt.Size = new System.Drawing.Size(100, 20);
            this.citytxt.TabIndex = 8;
            this.citytxt.Validating += new System.ComponentModel.CancelEventHandler(this.citytxt_Validating);
            this.citytxt.Validated += new System.EventHandler(this.citytxt_Validated);
            // 
            // ziptxt
            // 
            this.ziptxt.Location = new System.Drawing.Point(84, 160);
            this.ziptxt.Name = "ziptxt";
            this.ziptxt.Size = new System.Drawing.Size(100, 20);
            this.ziptxt.TabIndex = 10;
            this.ziptxt.Validating += new System.ComponentModel.CancelEventHandler(this.ziptxt_Validating);
            this.ziptxt.Validated += new System.EventHandler(this.ziptxt_Validated);
            // 
            // statecob
            // 
            this.statecob.FormattingEnabled = true;
            this.statecob.Location = new System.Drawing.Point(84, 129);
            this.statecob.Name = "statecob";
            this.statecob.Size = new System.Drawing.Size(121, 21);
            this.statecob.TabIndex = 11;
            this.statecob.Validating += new System.ComponentModel.CancelEventHandler(this.statecob_Validating);
            this.statecob.Validated += new System.EventHandler(this.statecob_Validated);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // okbtn
            // 
            this.okbtn.Location = new System.Drawing.Point(45, 234);
            this.okbtn.Name = "okbtn";
            this.okbtn.Size = new System.Drawing.Size(75, 23);
            this.okbtn.TabIndex = 12;
            this.okbtn.Text = "OK";
            this.okbtn.UseVisualStyleBackColor = true;
            this.okbtn.Click += new System.EventHandler(this.okbtn_Click);
            // 
            // cancelbtn
            // 
            this.cancelbtn.Location = new System.Drawing.Point(162, 233);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(75, 23);
            this.cancelbtn.TabIndex = 13;
            this.cancelbtn.Text = "Cancel";
            this.cancelbtn.UseVisualStyleBackColor = true;
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.okbtn);
            this.Controls.Add(this.statecob);
            this.Controls.Add(this.ziptxt);
            this.Controls.Add(this.citytxt);
            this.Controls.Add(this.addtxt2);
            this.Controls.Add(this.addtxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.ziplbl);
            this.Controls.Add(this.statelbl);
            this.Controls.Add(this.citylbl);
            this.Controls.Add(this.addresslbl);
            this.Controls.Add(this.namelbl);
            this.Name = "AddressForm";
            this.Text = "Address";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label namelbl;
        private System.Windows.Forms.Label addresslbl;
        private System.Windows.Forms.Label citylbl;
        private System.Windows.Forms.Label statelbl;
        private System.Windows.Forms.Label ziplbl;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox addtxt;
        private System.Windows.Forms.TextBox addtxt2;
        private System.Windows.Forms.TextBox citytxt;
        private System.Windows.Forms.TextBox ziptxt;
        private System.Windows.Forms.ComboBox statecob;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button cancelbtn;
        private System.Windows.Forms.Button okbtn;
    }
}