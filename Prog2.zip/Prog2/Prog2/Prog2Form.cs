﻿// E6445
// Program 2
// 10/19/2020
// CIS 200-76


// File: Prog2Form.cs
// This classe stores a list of US addresses consisting of name,
// two address lines, city, state, and 5 digit zip code.
// It performs certain actions for various menu items in the form
using Prog2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv;
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

            upv.AddAddress ("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
              "  Louisville   ", "  KY   ", 40202); // Test Address 1
            upv.AddAddress ("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            upv.AddAddress ("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            upv.AddAddress ("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            upv.AddAddress ("Jason Red ", "536 st drive", "Apt. 12",
               "New York", "NY", 99999); // Test Address 5
            upv.AddAddress ("Ashley Green", "789 magic way", "Apt. 6",
                "Detroit", "MI", 99998); // Test Address 6
            upv.AddAddress ("Matthew Indigo", "567 heaven Place", "Apt. 9",
                "San Francisco", "CA", 99997); // Test Address 7
            upv.AddAddress ("Wendy Brown", "873 Emerson Drive", "Apt. 11",
                "Paris", "KY", 99996); // Test Address 8

            upv.AddLetter(upv.AddressAt(1), upv.AddressAt(2), 4.55M);
            upv.AddLetter(upv.AddressAt(3), upv.AddressAt(4), 5.69M);

            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 10, 7.5, 8, 9.5);
            upv.AddGroundPackage(upv.AddressAt(0), upv.AddressAt(3), 13, 6.5, 5, 11);

            upv.AddNextDayAirPackage(upv.AddressAt(3), upv.AddressAt(5), 6, 9, 4, 10, 5.90M);
            upv.AddNextDayAirPackage(upv.AddressAt(6), upv.AddressAt(1), 8, 10, 3, 7, 6.50M);
            upv.AddNextDayAirPackage(upv.AddressAt(4), upv.AddressAt(1), 5, 20, 3, 13, 4.50M);
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: E6445\nCIS 200-76\nProgram 2\nDue: 10/19/20"); //shows info about program
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();//quits application
        }

        private void listAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine;
            foreach (Address a in upv.AddressList)
            {               
                maintxt.Text += $"{a}{NL}--------------------{NL}";
            }
                
        }

        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine;
            decimal totalCost = 0;
            foreach (Parcel p in upv.ParcelList)
            {
                maintxt.Text += $"{p}{NL}--------------------{NL}";

                totalCost += p.CalcCost();
            }
            maintxt.Text += $"{NL}--------------------{NL}Total Cost: {totalCost:C}";
        }

        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Prog2.AddressForm addressForm = new Prog2.AddressForm();
            DialogResult result; //Result from Dialog
            

            result = addressForm.ShowDialog();

            if (result == DialogResult.OK) //updates if user chooses OK
            {
                upv.AddAddress(addressForm.NameValue, addressForm.AddressValue1, addressForm.CityValue,
                    "CA", 40000);
            }

        }

        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm = new LetterForm(upv.AddressList);
                
            DialogResult result; //Result from Dialog


            result = letterForm.ShowDialog();

            if (result == DialogResult.OK) //updates if user chooses OK
            {
                upv.AddLetter(letterForm.OriginAddress, letterForm.DestinationAddress, letterForm.FixedCost);
            }
        }
    }
}
