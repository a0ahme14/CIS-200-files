﻿// E6445
// Program 2
// 10/19/2020
// CIS 200-76


// File: AddressForm.cs
// This class validates the data in the Address form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        public const int MIN_ZIP = 0;     // Minimum ZipCode value
        public const int MAX_ZIP = 99999; // Maximum ZipCode value
        

        public AddressForm()
        {
            InitializeComponent();

            List<string> states = new List<string> { "OH", "IN", "SC", "NC", "KY" };

            foreach (string state in states)
                statecob.Items.Add(state);
            

        }

        internal string StateValue // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in nametxt is returned
            get { return statecob.Text; }

            // Precondition:  None
            // Postcondition: Text in nametxt is set to specified value
            set { statecob.Text = value; }
        }
        private void statecob_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(statecob.Text))
            {
                e.Cancel = true; //stops focus changing process 
                                 //will not proceed to validated event
                errorProvider1.SetError(statecob, "Must select state");
                statecob.SelectAll(); //select all present text to ease correction
            }
        }
        private void statecob_Validated(object sender, EventArgs e)
        {
           // errorProvider1.SetError(statecob.Text, string.Empty);
        }


        internal string NameValue // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in nametxt is returned
            get { return nametxt.Text; }

            // Precondition:  None
            // Postcondition: Text in nametxt is set to specified value
            set { nametxt.Text = value; }           
        }

        private void nametxt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nametxt.Text))
            {
                e.Cancel = true; //stops focus changing process 
                                 //will not proceed to validated event

                errorProvider1.SetError(nametxt, "Enter a name");

                nametxt.SelectAll(); //select all present text to ease correction
            }
        }

        private void nametxt_Validated(object sender, EventArgs e)
        {
            //errorProvider1.SetError(nametxt, ""); //select all present text to ease correction
        }

        internal string AddressValue1 // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in nametxt is returned
            get { return addtxt.Text; }

            // Precondition:  None
            // Postcondition: Text in nametxt is set to specified value
            set { addtxt.Text = value; }
        }

        private void addtxt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(addtxt.Text))
            {
                e.Cancel = true; //stops focus changing process
                                 //will not proceed to validated event

                errorProvider1.SetError(addtxt, "Enter an Address");

                addtxt.SelectAll(); //select all present text to ease correction
            }
        }

        private void addtxt_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(addtxt, ""); //select all present text to ease correction
        }

        internal string AddressValue2 // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in nametxt is returned
            get { return addtxt2.Text; }

            // Precondition:  None
            // Postcondition: Text in nametxt is set to specified value
            set { addtxt2.Text = value; }
        }
        


        internal string CityValue // Can be accessed by other classes in same namespace
        {
            // Precondition:  None
            // Postcondition: Text in nametxt is returned
            get { return citytxt.Text; }

            // Precondition:  None
            // Postcondition: Text in nametxt is set to specified value
            set { citytxt.Text = value; }
        }

        private void citytxt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(citytxt.Text))
            {
                e.Cancel = true; //stops focus changing process 
                                 //will not proceed to validated event

                errorProvider1.SetError(citytxt, "Enter a city");

                addtxt.SelectAll();//select all present text to ease correction
            }
        }

        private void citytxt_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(citytxt, ""); //select all present text to ease correction
        }

        internal string ZipValue
        {
            get
            {
                return ziptxt.Text;
            }
            set
            {
                ziptxt.Text = value;
            }
        }

        private void ziptxt_Validating(object sender, CancelEventArgs e)
        {
            int zip; //address' zip code
            if (!int.TryParse(ziptxt.Text, out zip))
            {
                e.Cancel = true; //stops focus changing process 
                                 //will not proceed to validated event
                errorProvider1.SetError(ziptxt, "Enter a correct zip!");
                ziptxt.SelectAll();//select all present text to ease correction
            }
            else
            {
                if (zip < MIN_ZIP || zip > MAX_ZIP)
                {
                    e.Cancel = true; //stops focus changing process 
                                     //will not proceed to validated event
                    errorProvider1.SetError(ziptxt, "Enter a correct zip!");
                    ziptxt.SelectAll(); //select all present text to ease correction
                }
            }
        }

        private void ziptxt_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ziptxt, ""); 
        }

        // Precondition:  User has initiated click on cancelBtn
        
        private void cancelbtn_Click(object sender, EventArgs e)
        {
            
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  User has initiated click on OkBtn
        // Postcondition: If all controls on form validate, InputBox is dismissed with OK result
        private void okbtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
